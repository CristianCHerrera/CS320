package contact;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
	void testAddContact() {
		ContactService contactList = new ContactService();
		Contact test1 = new Contact("123456","John", "Smith", "5031231234", "123 Rainbow Rd");
		
		assertEquals(true, contactList.addContact(test1));
}
	
	@Test
	void testAddContactTwice() {
		ContactService contactList = new ContactService();
		Contact test1 = new Contact("123456","John", "Smith", "5031231234", "123 Rainbow Rd");
		
		assertEquals(true, contactList.addContact(test1));
		assertEquals(false,contactList.addContact(test1));
}
	
	@Test
	void testUpdateContact() {
		ContactService contactList = new ContactService();
		Contact test1 = new Contact("123456","John", "Smith", "5031231234", "123 Rainbow Rd");
		Contact test2 = new Contact("234567","Smith", "John", "5033211234", "122 Rainbow Rd");
		
		assertEquals(true, contactList.addContact(test1));
		assertEquals(true, contactList.addContact(test2));
		
		assertEquals(true, contactList.updateContact("123456", "Smith", "John", "5033211234", "122 Rainbow Rd"));
	}
	
	@Test
	void testUpdateContactNotInList() {
		ContactService contactList = new ContactService();
		Contact test1 = new Contact("123456","John", "Smith", "5031231234", "123 Rainbow Rd");
		Contact test2 = new Contact("234567","Smith", "John", "5033211234", "122 Rainbow Rd");
		
		assertEquals(true, contactList.addContact(test1));
		assertEquals(true, contactList.addContact(test2));
		
		assertEquals(true, contactList.updateContact("123456", "Smith", "John", "5033211234", "122 Rainbow Rd"));
		assertEquals(false, contactList.updateContact("999999", "Smith", "John", "5033211234", "122 Rainbow Rd"));
	}
}
