package contact;
import java.util.*;  

public class ContactService {

	ArrayList<Contact> contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	
	public boolean addContact(Contact contact) {
		
		boolean check = contacts.contains(contact);
		if (check == false) {
			contacts.add(contact);
			return true;
		}
		else {
			System.out.println("Contact ID already in Database");
			return false;
		}
	}
	
	public boolean removeContact(String contactId) {
		
		for (Contact current : contacts) {
			if (current.getContact().equals(contactId)) {
				contacts.remove(current);
				return true;
			}
		}
		return false;
	}
	
	public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
		
		for (Contact current : contacts) {
			if (current.getContact().equals(contactId)) {
				current.setFirst(firstName);
				current.setLast(lastName);
				current.setPhone(phone);
				current.setAddress(address);
				return true;
			}
		}
		return false;
	}

}