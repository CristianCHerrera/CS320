package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



class ContactTest {

	@Test
	void testContactClass() {
		Contact contact = new Contact("123456", "John", "Smith", "5031231234", "123 Rainbow Rd");
		assertTrue(contact.getContact().equals("123456"));
		assertTrue(contact.getFirst().equals("John"));
		assertTrue(contact.getLast().equals("Smith"));
		assertTrue(contact.getPhone().equals("5031231234"));
		assertTrue(contact.getAddress().equals("123 Rainbow Rd"));
	}

	@Test
	void testContactIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null,"John", "Smith", "5031231234", "123 Rainbow Rd");
		});
	}

	@Test
	void testContactIdIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910","John", "Smith", "5031231234", "123 Rainbow Rd");
		});
	}
	
	@Test
	void testFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", null, "Smith", "5031231234", "123 Rainbow Rd");
		});
	}

	@Test
	void testFirstNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910","JohnJohnJohn", "Smith", "5031231234", "123 Rainbow Rd");
		});
	}
	
	@Test
	void testLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "John", null, "5031231234", "123 Rainbow Rd");
		});
	}

	@Test
	void testLastNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910","JohnJohnJohn", "SmithSmithSmith", "5031231234", "123 Rainbow Rd");
		});
	}
	
	@Test
	void testPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "John", "Smith", null, "123 Rainbow Rd");
		});
	}

	@Test
	void testPhoneIsNot10() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910","JohnJohnJohn", "Smith", "123", "123 Rainbow Rd");
		});
	}
	
	@Test
	void testAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "John", "Smith", "5031231234", null);
		});
	}

}


